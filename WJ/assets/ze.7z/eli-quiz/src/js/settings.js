
//let serverUrl = "http://211.95.56.10:9780/frontend";
let serverUrl;
if(process.env.NODE_ENV === "release"){
  serverUrl = "https://api.elitolove.com/"
}else{
  serverUrl = 'http://api.dev.huadongmedia.com:10016/';
  // serverUrl = 'http://192.168.0.247:10016/';
}
if(process.env.MOCK === "true"){
  serverUrl = "/mock";
}
export { serverUrl };