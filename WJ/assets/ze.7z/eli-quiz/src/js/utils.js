export function query(name, source) {
  /* eslint-disable */
  name = name.replace(/[\[]/, '\\\[').replace(/[\]]/, '\\\]');
  let url = source || location.search;
  let regex = new RegExp('[\\?&]' + name + '=([^&#]*)'),
      results = regex.exec(url);
  return results == null ? '' : decodeURIComponent(results[1]);
}

export function is_ios() {
  if (/(iPhone|iPad|iPod|iOS)/i.test(navigator.userAgent)) {
    return true;
  } else {
    return false;
  }
}

export function is_weixin() {
  var ua = navigator.userAgent.toLowerCase();
  if (ua.match(/MicroMessenger/i) == "micromessenger") {
    return true;
  } else {
    return false;
  }
}

var weixin_wait = 2;
function weixin_time() {
  if (weixin_wait == 0) {
    $("#topiframe").remove();
    $("#zzbg").remove();
    weixin_wait = 2;
  } else {
    weixin_wait--;
    setTimeout(function() {
      weixin_time();
    }, 1000)
  }
}

export function downLoadApk(apk) {
  if (is_weixin()) {
    $("<div id='topiframe' style='position:fixed; _position:absolute; top:14px; z-index:20000; width:100%; height:75px; background:#fff; font:14px/25px 微软雅黑; color:#6a6a6a; padding:15px 0;'><div style='width:80%;float:right; margin-right:30px;'>微信请点击右上角 <span style='width:16px; height:16px; display:inline-block; background:url(http://huisuoping.com:80/resources/moneyLock_images/layerimg.png) no-repeat; vertical-align:middle; margin-top:-2px; margin-right:5px;'></span>, 使用“在浏览器中打开”, 即可下载体验。<s style='width:31px; height:14px; background:url(http://huisuoping.com:80/resources/moneyLock_images/arrow.png) no-repeat; display:block; position:absolute; top:-14px; right:-2px;'></s></div></div><div id='zzbg' style='background-color:#000; width:100%; height:100%; left:0; top:0; filter:alpha(opacity=80); opacity:0.8; z-index:19999; position:fixed!important; position:absolute;'></div>").appendTo("body");
    weixin_time();
  }
  else if (is_ios()) {
    location.href = "https://itunes.apple.com/cn/app/id1499296263";
    return;
  }
  else {
    if (!apk) {
      location.href = "http://file.sports.huadongmedia.com/apk/eli.apk";;
    } else {
      location.href = "https://file.cashtoutiao.com/apk/" + apk + ".apk";
    }
  }
}
/*
export function getUserDetailInfo() {
  if (window.hsputil) {
    let userInfo = window.hsputil.getUserInfo();
    let user = eval("(" + userInfo + ")");
    let userId = user.id;
    let loginId = user.loginId;
    let channel = user.channel;
    // alert(JSON.stringify({ userId, loginId, channel }))
    return { userId, loginId, channel };
  }
  return null;
}*/

var win = window['eliHandler']
export function getUserDetailInfo() {
  if (win) {
    let userInfo = win.getUserInfo();
    let user = eval("(" + userInfo + ")");
    let userId = user.userInfo.userId;
    let loginId = user.loginId;
    let gender = user.userInfo.gender;
    // let channel = user.channel;
    // alert(JSON.stringify({ userId, loginId, channel }))
    return { userId, loginId,gender};
  }
  // else if(isDebug){
  //   let loginId = 30, userId = 30;
  //   return { userId, loginId};
  // }
  return null;
}

export function getAppDetailInfo() {
  if (win) {
    let AppInfo = win.getAppInfo();
    let user = eval("(" + AppInfo + ")");
    let platform = user.platform;
    let appCode = user.appCode;
    let channel = user.channel;
    let appVersion = user.appVersion;
    return { platform, appCode, channel, appVersion };
  }
  // else if(isDebug){
  //   return {}
  // }
  return null;
}

const utils = {
  query,
  is_ios,
  is_weixin,
  downLoadApk,
  getUserDetailInfo,
  getAppDetailInfo
}

export default utils;