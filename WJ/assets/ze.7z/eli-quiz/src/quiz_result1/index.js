import utils from '@/js/utils'
// import { serverUrl } from '@/js/settings'

import '@/scss/base.scss'
import './index.scss'

// import Bootstrap from 'bootstrap/dist/css/bootstrap.min.css'
// import 'bootstrap/dist/css/bootstrap.min.css'

// import 'vue'
// import Vue from 'vue'
//window.Vue = require('vue')

//var serverUrl = (process.env.MOCK=="enable")? "": "http://211.95.56.10:9780/frontend";
//console.log(process.env.NODE_ENV, process.env.MOCK=="true"? "mock=true":'', serverUrl)

//var userId = '211442254', loginId = 'b5ee76edc53d4e0db95b5e26295f5d7f';
// let { userId, loginId }  = utils.getUserDetailInfo() || {}

$(function() {
    /*const _handleClick = function(fn, data, index) {
      let $elem = $(this);
      if($elem.hasClass('off-click'))
        return;
      console.log('@click', data, index)
      fn.call(this, data, index)
    }
    function getReward(taskId) {
      let $elem = $(this);
      $elem.addClass('off-click')
      return $.ajax({
        type: "post",
        url: serverUrl+`/web/mini/game/draw?userId=${userId}&loginId=${loginId}`,
        data: JSON.stringify({userId, taskId}),
        dataType: "json",
        contentType: "application/json"
      })
      .then(function(resp){
        let { statusCode, msg, reward } = resp;
        if(statusCode === 200){
          $elem.attr('class',"gained").html('已领取'); 
          iqwerty.toast.Toast(`领到${reward}金币`);
        }
        else {
          throw resp;
        }
      })
      .catch(e => {
        let error_str = "网络出错了，请稍后再试"
        if(e.msg){
          error_str = msg
        }
        iqwerty.toast.Toast(error_str);
        setTimeout(() => {
          $elem.removeClass('off-click')
        },3000)
      })
    }*/

    let type = utils.query('type')
    let lover_type = utils.query('lover_type')
    let name = utils.query('name')
    name = decodeURIComponent(name) 
    console.log(name,type,lover_type)

    if(name && type && lover_type){
      const map1 = ['焦虑型','回避型','安全型']
      let my_type = map1[parseInt(type)]
      if(parseInt(type*10)%10==1){
        my_type = '强度' + my_type;
      }else {
        my_type = '弱度' + my_type;
      }
      document.body.innerHTML = document.body.innerHTML.replace(/YY/g,my_type)

      document.body.innerHTML = document.body.innerHTML.replace(/XX/g,name)
      $(".page").eq(parseInt(type)).css('display','block')
    }

    $(".next").click(function(){
      location.href = location.href.replace(/quiz_result1\.html.*$/,`quiz_result2.html?name=${encodeURIComponent(name)}&type=${type}&lover_type=${lover_type}`)
    })
  //$('strong').html(fmoney(123232439.3223,2))
  //new Promise(function(resolve,reject){setTimeout(()=>{let a=10;resolve(a)},2000)}).then((x)=>{console.log('Promise'+x)})
})