import utils from '@/js/utils'
import { serverUrl } from '@/js/settings'
import TPL from './index.art'

import '@/scss/base.scss'
import './index.scss'

// import Bootstrap from 'bootstrap/dist/css/bootstrap.min.css'
// import 'bootstrap/dist/css/bootstrap.min.css'

// import 'vue'
// import Vue from 'vue'
//window.Vue = require('vue')

//var serverUrl = (process.env.MOCK=="enable")? "": "http://211.95.56.10:9780/frontend";
//console.log(process.env.NODE_ENV, process.env.MOCK=="true"? "mock=true":'', serverUrl)

 var userId='100000053',loginId='39a838cd197b4e218289235d467e5a85'
// let { userId, loginId }  = utils.getUserDetailInfo() || {
//   userId: 3111,
//   loginId: '9b8e82ef638949f8aab9ece5ad06f8b8'
// }
let t1, t2, name

$(function() {


    const POS = '0', NEG='2', NOR = '1';
    
    function score(dataList){console.log(dataList)
      let counter = [0,0,0]// 不安数，回避数，安全数
      dataList.forEach(({qid, a}) => {
        // console.log(qid)
        if(qid%2==1){
          if(a==POS)
            counter[1] += 1
          else if(a==NEG)
            counter[1] -= 1
        }
        else{
          if(a==POS)
            counter[0] += 1
          else if(a==NEG)
            counter[0] -= 1
        }
      })
      counter[2] = counter[0]+counter[1]
      return counter;
    }

    function analysis(counter){
      const map1 = {'焦虑型':0,'回避型':1,'安全型':2}, map2 = {'弱度':0,'强度':1}
      let str1 = '', str2 = '';
      if(counter[0]>0 && counter[1]>0){
        str1 += counter[1]>counter[0] ? '回避型':'焦虑型'
        str2 += (counter[1]>5 || counter[0]>5)? '强度': '弱度'
      }
      else if(counter[0]>0){
        str1 += '焦虑型'
        str2 += counter[0]>5? '强度': '弱度'
      }
      else if(counter[1]>0){
        str1 += '回避型'
        str2 += counter[1]>5? '强度': '弱度'
      }
      else if(counter[0]==0 && counter[1]==0){
        str1 = '回避型'
        str2 = '弱度'
      }
      else {
        str1 += '安全型'
        str2 += counter[2]<-11? '强度': '弱度'
      }
      console.log(JSON.stringify(counter), str1+map1[str1], str2+map2[str2])
      return (map1[str1] + 0.1 * map2[str2]).toFixed(1)
    }

    function getDetail() {
      let quizResultId = utils.query('id')
      return $.ajax({
        type: "post",
        url: serverUrl+`quiz/answer/detail`,//?userId=${userId}&loginId=${loginId}
        data: JSON.stringify({quizResultId:parseInt(quizResultId), userId, loginId}),
        dataType: "json",
        contentType: "application/json"
      })
    }

    getDetail()
      .then(function(resp){
        let { statusCode, nickName, dataList } = resp;
        // console.log(resp)
        if(statusCode === 200){
          name  = nickName || "你";
          const len = dataList.length/2;
          let selfScore = score(dataList.filter((_)=>(_.qid <= len)))
          t1 = analysis(selfScore)
          console.log(t1)
          let loverScore = score(dataList.filter((_)=>(_.qid > len)))
          t2 = analysis(loverScore)
          console.log(t2)

          let nameType
          if (t1[0] == 0) {
            nameType = '焦虑型'
          } else if (t1[0] == 1) {
            nameType = '回避型'
          } else if (t1[0] == 2) {
            nameType = '安全型'
          }
          let nameTypeLevel
          if (t1[2] == 1) {
            nameTypeLevel = '强度'
          } else {
            nameTypeLevel = '弱度'
          }


          let loverType
          if (t2[0] == 0 && t1[0] == 0) {
            loverType = '焦虑型'
          } else if (t2[0] == 1 && t1[0] == 1) {
            loverType = '回避型'
          } else if (t2[0] == 2 && t1[0] == 2) {
            loverType = '安全型'
          } else if(t2[0] == 0 && t1[0] != 0){
            loverType = '焦虑型'
          } else if(t2[0] == 1 && t1[0] != 1){
            loverType = '回避型'
          } else if(t2[0] == 2 && t1[0] != 2){
            loverType = '安全型'
          }
          var loverTypeLevel
          if (t2[2] == 1) {
            loverTypeLevel = '强度'
          } else {
            loverTypeLevel = '弱度'
          }

          let page = 0;
          let showPage = () => {
            $("#app").html("")
            $("#app")[0].scrollIntoView();
            $("#app").html(
                TPL({
                  page: ++page,
                  name,
                  nameType,//:'安全型',
                  nameTypeLevel,
                  loverType,//:'回避型',
                  loverTypeLevel
                })
              )
            $(".go_next").click(showPage)
          }
          showPage()
        }
        else {
          throw error;
        }
      })
      .catch(e => {
        iqwerty.toast.Toast("网络出错了，请稍后再试");
      })    


      /*

    let resp = {
      statusCode:200,
      msg:'ok',
      quizId:1,
      nickName:'John',
      dataList:[
        {qid:1, a:POS},
        {qid:2, a:POS},
        {qid:3, a:NOR},
        {qid:4, a:NEG},
      ]
    }
    name  = resp.nickName;
    const len = resp.dataList.length/2;
    let selfScore = score(resp.dataList.filter((_)=>(_.qid <= len)))
    t1 = analysis(selfScore)
    console.log(t1)
    let loverScore = score(resp.dataList.filter((_)=>(_.qid > len)))
    t2 = analysis(loverScore)
    console.log(t2)
    */

    $(".next").click(function(){
      if(name && t1 && t2)
        location.href = location.href.replace(/quiz_result\.html.*$/,`quiz_result1.html?name=${encodeURIComponent(name)}&type=${t1}&lover_type=${t2}`)
    })
  //$('strong').html(fmoney(123232439.3223,2))
  //new Promise(function(resolve,reject){setTimeout(()=>{let a=10;resolve(a)},2000)}).then((x)=>{console.log('Promise'+x)})
})