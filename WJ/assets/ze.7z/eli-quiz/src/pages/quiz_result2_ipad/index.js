import TPL from './index.art'
import utils from '@/js/utils'
import {
  serverUrl
} from '@/js/settings'

import '@/scss/base.scss'
import './index.scss'


$(function () {
  const NEG = '2', NOR = '1';

  let recordId = utils.query('id')
  let quizNo = utils.query('quizNo')
  let vipHave = utils.query('vip') == '1'

  function getDetail() {
    return $.ajax({
        type: "post",
        url: serverUrl + `support/record/result`, //?userId=${userId}&loginId=${loginId}
        data: JSON.stringify({
          recordId: parseInt(recordId),
          quizNo
        }),
        dataType: "json",
        contentType: "application/json"
      })
  }

  getDetail()
      .then(function (resp) {
        let {
          statusCode,
          nickName,
          result
        } = resp;
        // console.log(resp)
        if (statusCode === 200) {
          // 1-7题为①内向（E）-②外向(I)，
          // 2-14题为①直觉（N）-②感觉（S）
          // 15-21题为②思考（T）-①情感（F）
          // 22-28题为①判断的（J)-②感知（P）
          var answers = JSON.parse(result.answers)

          var a = [1, 2, 3, 4, 5, 6, 7]
          var b = [8, 9, 10, 11, 12, 13, 14]
          var c = [15, 16, 17, 18, 19, 20, 21]
          var d = [22, 23, 24, 25, 26, 27, 28]
          var eori = answers.filter((itm, index) => a.indexOf(index + 1) >= 0)
          var nors = answers.filter((itm, index) => b.indexOf(index + 1) >= 0)
          var torf = answers.filter((itm, index) => c.indexOf(index + 1) >= 0)
          var jorp = answers.filter((itm, index) => d.indexOf(index + 1) >= 0)

          function score(dataList) {
            let counter = [0, 0, 0]
            dataList.forEach(({
              qid,
              a
            }) => {
              if (qid) {
                if (a == NOR) {
                  counter[0] += 1
                } else if (a == NEG) {
                  counter[1] += 1
                }
              }
              // else {
              //   if (a == NEG) {
              //     counter[0] -= 1
              //   } else if (a == NOR) {
              //     counter[0] += 1
              //   }
              // }
            })
            if (counter[0] > counter[1]) {
              counter[2] = 0
            } else {
              counter[2] = 1
            }
            return counter;
          }
          var data = [score(eori), score(nors), score(torf), score(jorp)]
          const resMap = [
            ['E', 'I'],
            ['N', 'S'],
            ['F', 'T'],
            ['J', 'P']
          ]
          let nameID = ""
          data.forEach((v, i) => {
            if (v) {
              var index = v.length - 1;
              nameID += resMap[i][v[index]];
            }
          })

          $("#app").html(TPL({ vipHave }))

          if (vipHave == 0) {
            $("#noVip").css("display", "block")
          } else {
            $("#haveVip").css("display", "block")
            $(".icoImg").css("display", "inline-block")
            $(".card1").css("height", "55px");
            $(".card1").css("overflow", "hidden")
            var flay = true
            $(".card1").click(function (e) {
              $(this).css("height", "auto");
              $(this).find(".icoImg").css("display", "none")
              $(this).find(".icoImg1").css("display", "inline-block")
            })
          }

          if (nameID[0] == "I") {
            var percentage = Math.round((Math.round(score(eori)[1] / 7 * 10000) / 100)) + "%"
            if (percentage != "100%") {
              $(".earticlei").css({
                "width": percentage,
                "float": "right",
                "background": "linear-gradient(270deg, #2684DB 0%, #4EBAEF 100% )",
                "height": "26PX",
                "border-radius": "13PX"
              })
            } else {
              $(".earticlei").css({
                "width": percentage,
                "background": "linear-gradient(270deg, #2684DB 0%, #4EBAEF 100% )",
                "height": "26PX",
                "border-radius": "13PX "
              })
            }
            $(".itext").css("color", "#2684DB")
            $(".iround").css("color", "#2684DB")
            $('.iround').html(percentage)
            $('.eround').html(100 - Math.round((Math.round(score(eori)[1] / 7 * 10000) / 100)) + "%")
          } else {
            var percentage = Math.round((Math.round(score(eori)[0] / 7 * 10000) / 100.00)) + "%"
            if (percentage != "100%") {
              $(".earticlei").css({
                "width": percentage,
                "background": "linear-gradient(270deg, #2684DB 0%, #4EBAEF 100% )",
                "height": "26PX",
                "border-radius": "13PX"
              })
            } else {
              $(".earticlei").css({
                "width": percentage,
                "background": "linear-gradient(270deg, #2684DB 0%, #4EBAEF 100% )",
                "height": "26PX",
                "border-radius": "13PX"
              })
            }
            $(".etext").css("color", "#2684DB")
            $(".eround").css("color", "#2684DB")
            $('.eround').html(percentage)
            $('.iround').html(100 - Math.round((Math.round(score(eori)[0] / 7 * 10000) / 100)) + "%")
          }
          if (nameID[1] == "S") {
            var percentage1 = Math.round(Math.round(score(nors)[1] / 7 * 10000) / 100.00) + "%"
            if (percentage1 != "100%") {
              $(".sarticlen").css({
                "width": percentage1,
                "background": "linear-gradient(270deg, #C12138 0%, #E24569 100% )",
                "height": "26PX",
                "border-radius": "13PX"
              })
            } else {
              $(".sarticlen").css({
                "width": percentage1,
                "background": "linear-gradient(270deg, #C12138 0%, #E24569 100% )",
                "height": "26PX",
                "border-radius": "13PX"
              })
            }

            $(".stext").css("color", "#C12138")
            $(".sround").css("color", "#C12138")
            $('.sround').html(percentage1)
            $('.nround').html(100 - Math.round((Math.round(score(nors)[1] / 7 * 10000) / 100)) + "%")
          } else {
            var percentage1 = Math.round(Math.round(score(nors)[0] / 7 * 10000) / 100.00) + "%"
            if (percentage1 != "100%") {
              $(".sarticlen").css({
                "width": percentage1,
                "background": "linear-gradient(270deg, #C12138 0%, #E24569 100% )",
                "float": "right",
                "height": "26PX",
                "border-radius": "13PX"
              })
            } else {
              $(".sarticlen").css({
                "width": percentage1,
                "background": "linear-gradient(270deg, #C12138 0%, #E24569 100% )",
                "height": "26PX",
                "border-radius": "13PX"
              })
            }

            $(".ntext").css("color", "#C12138")
            $(".nround").css("color", "#C12138")
            $('.nround').html(percentage1)
            $('.sround').html(100 - Math.round((Math.round(score(nors)[0] / 7 * 10000) / 100)) + "%")
          }
          if (nameID[2] == "F") {
            var percentage2 = Math.round(Math.round(score(torf)[0] / 7 * 10000) / 100.00) + "%"
            if (percentage2 != "100%") {
              $(".tarticlef").css({
                "width": percentage2,
                "background": "linear-gradient(270deg, #E28A48 0%, #F3BE7E 100% )",
                "float": "right",
                "height": "26PX",
                "border-radius": "13PX"
              })
            } else {
              $(".tarticlef").css({
                "width": percentage2,
                "background": "linear-gradient(270deg, #E28A48 0%, #F3BE7E 100% )",
                "height": "26PX",
                "border-radius": "13PX"
              })
            }

            $(".ftext").css("color", "#E28A48")
            $(".fround").css("color", "#E28A48")
            $('.fround').html(percentage2)
            $('.tround').html(100 - Math.round((Math.round(score(torf)[0] / 7 * 10000) / 100)) + "%")
          } else {
            var percentage2 = Math.round(Math.round(score(torf)[1] / 7 * 10000) / 100.00) + "%"
            if (percentage2 != "100%") {
              $(".tarticlef").css({
                "width": percentage2,
                "background": "linear-gradient(270deg, #E28A48 0%, #F3BE7E 100% )",
                "height": "26PX",
                "border-radius": "13PX  "
              })
            } else {
              $(".tarticlef").css({
                "width": percentage2,
                "background": "linear-gradient(270deg, #E28A48 0%, #F3BE7E 100% )",
                "height": "26PX",
                "border-radius": " 13PX"
              })
            }

            $(".ttext").css("color", "#E28A48")
            $(".tround").css("color", "#E28A48")
            $('.tround').html(percentage2)
            $('.fround').html(100 - Math.round((Math.round(score(torf)[1] / 7 * 10000) / 100)) + "%")
          }
          if (nameID[3] == "P") {
            var percentage3 = Math.round(Math.round(score(jorp)[1] / 7 * 10000) / 100.00) + "%"
            if (percentage3 != "100%") {
              $(".jarticlep").css({
                "width": percentage3,
                "background": "linear-gradient(270deg, #933EC0 0%, #C572E1 100% )",
                "float": "right",
                "height": "26PX",
                "border-radius": "13PX"
              })
            } else {
              $(".jarticlep").css({
                "width": percentage3,
                "background": "linear-gradient(270deg, #933EC0 0%, #C572E1 100% )",
                "height": "26PX",
                "border-radius": "13PX"
              })
            }
            $(".ptext").css("color", "#933EC0")
            $(".pround").css("color", "#933EC0")
            $('.pround').html(percentage3)
            $('.jround').html(100 - Math.round((Math.round(score(jorp)[1] / 7 * 10000) / 100)) + "%")
          } else {
            var percentage3 = Math.round(Math.round(score(jorp)[0] / 7 * 10000) / 100.00) + "%"
            if (percentage3 != "100%") {
              $(".jarticlep").css({
                "width": percentage3,
                "background": "linear-gradient(270deg, #933EC0 0%, #C572E1 100% )",
                "height": "26PX",
                "border-radius": "13PX  "
              })
            } else {
              $(".jarticlep").css({
                "width": percentage3,
                "background": "linear-gradient(270deg, #933EC0 0%, #C572E1 100% )",
                "height": "26PX",
                "border-radius": " 13PX"
              })
            }

            $(".jtext").css("color", "#933EC0")
            $(".jround").css("color", "#933EC0")
            $('.jround').html(percentage3)
            $('.pround').html(100 - Math.round((Math.round(score(jorp)[0] / 7 * 10000) / 100)) + "%")
          }

          $.getJSON("result2_ipad.json").then((result) => {
            nameID
            $(".NameType").html(result[nameID].NameType);
            $(".details_top").html(result[nameID].top);
            $(".details_btm").html(result[nameID].topText);
            $("#loveIng").html(result[nameID].loveing);
            $("#womanText").html(result[nameID].womanText);
            $("#manText").html(result[nameID].manText);
            $("#occasion").html(result[nameID].occasion);
            $("#winLove").html(result[nameID].winLove);
            $("#longLove").html(result[nameID].longLove);
          })

        } else {
          throw error;
        }
      })
      .catch(e => {
        iqwerty.toast.Toast("网络出错了，请稍后再试");
      })

})