import utils from '@/js/utils'
import { serverUrl } from '@/js/settings'

import './index.scss'