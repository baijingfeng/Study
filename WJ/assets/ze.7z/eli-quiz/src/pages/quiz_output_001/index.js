import utils from '@/js/utils'
import { serverUrl } from '@/js/settings'
import TPL from './index.art'

import '@/scss/base.scss'
import './index.scss'

const userId = '100000053',
	loginId = '39a838cd197b4e218289235d467e5a85'
let scoreArray
// let recordId = utils.query('id')
// let quizNo = utils.query('quizNo')

$(function () {
	const ajaxParams = {
		type: 'post',
		url: serverUrl + `quiz/answer/detail`, //?userId=${userId}&loginId=${loginId}
		data: JSON.stringify({
			quizResultId: parseInt(utils.query('id')),
			userId,
			loginId,
		}),
		dataType: 'json',
		contentType: 'application/json',
	}

	const func3 = answers => {
		var Agape = [4, 11, 14, 26, 30]
		var Eros = [1, 5, 13, 22, 28]
		var Ludus = [3, 7, 9, 12, 29]
		var Mania = [2, 16, 19, 21, 24]
		var Pragama = [6, 18, 23, 25, 27]
		var Storge = [8, 10, 15, 17, 20]
		var AgapeNum = answers.filter((itm, index) => Agape.indexOf(index + 1) >= 0)
		var ErosNum = answers.filter((itm, index) => Eros.indexOf(index + 1) >= 0)
		var LudusNum = answers.filter((itm, index) => Ludus.indexOf(index + 1) >= 0)
		var ManiaNum = answers.filter((itm, index) => Mania.indexOf(index + 1) >= 0)
		var PragamaNum = answers.filter((itm, index) => Pragama.indexOf(index + 1) >= 0)
		var StorgeNum = answers.filter((itm, index) => Storge.indexOf(index + 1) >= 0)
		console.log(AgapeNum, ErosNum, LudusNum, ManiaNum, PragamaNum, StorgeNum)

		const computeScore = dataList => 10 * dataList.reduce((scoreCount, { a }) => scoreCount + a, 0)
		scoreArray = [
			{
				score: computeScore(AgapeNum),
				name: 'Agape',
				item: '奉献型',
				color: 'rgba(226,138,72,1)',
				example:
					'如果恋人说要和异性同时单独吃饭？<br />奉献型：我知道有一家餐厅挺适合谈工作的，我来帮你预约吧<br /><span style="color: rgba(0,0,0,0.5);font-size: 17px;">内心os：要和同事出去吃饭？那我要为ta创造好一切条件！</span>',
				html:
					'奉献型的人是即使只有付出，也会感到幸福的人! 奉献型的人心胸宽阔，不求另一半给予回报，仅给予奉献就能够感到满足。Ta们喜欢好好照顾恋人，让恋人感到幸福。恋人因自己的努力而高兴的样子是Ta们最大的幸福。在恋爱过程中，即使有点累，ta们也会为了恋人而做出牺牲和让步。即使恋爱中遇到困难,也会努力克服。即使对方有错，Agape的人一般情况下都会努力理解。Ta们能忍受恋人对自己说出过分的话。Ta们也会经常送恋人礼物，不管是否是纪念日。奉献型的人愿意为了恋人进行改变。',
				background: 'linear-gradient(90deg,rgba(243,190,126,1) 0%,rgba(226,138,72,1) 100%);',
			},
			{
				score: computeScore(ErosNum),
				name: 'Eros',
				item: '浪漫型',
				color: 'rgba(193,33,56,1)',
				background: 'linear-gradient(90deg,rgba(226,69,105,1) 0%,rgba(193,33,56,1) 100%);',
				example:
					'如果恋人说要和异性同时单独吃饭？<br />浪漫型：要和其他异性吃饭啊～好吧，吃完早点回来哦～<br /><span style="color: rgba(0,0,0,0.5);font-size: 17px;">内心os：居然和异性单独吃饭！有点嫉妒，但好像也没什么太大的问题</span>',
				html:
					'浪漫型喜欢充满热情的浪漫爱情。浪漫型的人更喜欢表达爱意，特别是身体接触！Ta们更重视恋人的外貌，所以看到性感的异性会一见钟情。一旦开始恋爱，ta们希望关系会变得很亲密。不管是什么，都想与对方共享。Ta们喜欢身体接触，也喜欢深入交谈。浪漫型的人看到恋人与其他异性在一起时会嫉妒。',
			},
			{
				score: computeScore(LudusNum),
				name: 'Ludus',
				item: '游戏型',
				color: 'rgba(38,132,219,1)',
				background: 'linear-gradient(90deg,rgba(78,186,239,1) 0%,rgba(38,132,219,1) 100%);',
				example:
					'如果恋人说要和异性同时单独吃饭？<br />游戏型：那正好，我也要和我的一个异性同事一起吃饭，要不我们约在一家餐厅？！<br /><span style="color: rgba(0,0,0,0.5);font-size: 17px;">内心os：我也要去见其他的异性，你去见别人也无所谓</span>',
				html:
					'游戏型追求无忧无虑的爱情! 对于游戏型的人来说，恋爱更像游戏，而不是爱情。Ta们没有固定的理想型，各种风格的异性都喜欢。Ta们不喜欢真挚而深刻的恋爱，一直想和恋人保持距离。 "从这儿开始就是我的生活，不要过界！" 游戏型的人也不太会表达爱意。Ta们喜欢推拉，不喜欢缠着恋人，所以从对方的立场来看，可能有些不满。Ta们对热烈肉麻的恋爱感到负担。游戏型的人也不喜欢恋人纠缠自己。比起主动告白，ta们更喜欢跟告白的人开始恋爱。',
			},
			{
				score: computeScore(ManiaNum),
				name: 'Mania',
				item: '占有型',
				color: 'rgba(147,62,192,1)',
				background: 'linear-gradient(90deg,rgba(197,114,225,1) 0%,rgba(147,62,192,1) 100%);',
				example:
					'如果恋人说要和异性同时单独吃饭？<br />占有型：为什么要和ta一起吃饭？你要在哪里吃? 能带我一起去吗？<br /><span style="color: rgba(0,0,0,0.5);font-size: 17px;">内心os：要和同事出去吃饭？那我要为ta创造好一切条件！</span>',
				html:
					'占有型是对爱情孤注一掷的人。对占有型的人来说，只要恋人的态度稍有改变，就会非常不安。因为担心恋人是否会讨厌自己，所以ta们经常感到压力。很多时候觉得恋人对自己的爱不够，很依赖恋人，经常问恋人是否爱自己。Ta们的自尊心很强，需要恋人表现出关心和爱。占有型的人很渴望爱情。Ta们常常担心恋人会出轨。',
			},
			{
				score: computeScore(PragamaNum),
				name: 'Pragama',
				item: '现实型',
				color: 'rgba(0,185,132,1)',
				background: 'linear-gradient(90deg,rgba(0,205,102,1) 0%, rgba(0,185,132,1)100%);',
				example:
					'如果恋人说要和异性同时单独吃饭？<br />现实型：有工作要谈是吧，理解理解，你们好好吃吧！<br /><span style="color: rgba(0,0,0,0.5);font-size: 17px;">内心os：我的客观判断是有工作要谈，我理解</span>',
				html:
					'比起肉体，现实型更喜欢“理性”恋爱。对于现实型的人来说，恋爱是现实的。Ta们从开始寻找恋人时就与众不同，首先会对对方进行非常细致的观察和评价，了解对方是否适合自己。Ta们不喜欢烟火一样短暂的爱情，比任何人都希望能够长久的交往。对方对自己人生是否有帮助是现实型的人考虑开始恋爱的重要因素。Ta们喜欢可以互相负责的爱情。现实型的人不相信命中注定的爱情，会根据个人需求开始恋爱。Ta们更喜欢跟自己成长环境相似的人恋爱。',
			},
			{
				score: computeScore(StorgeNum),
				name: 'Storge',
				item: '友谊型',
				color: 'rgba(244,170,43,1)',
				background: 'linear-gradient(90deg,rgba(250,213,86,1) 0%,rgba(244,170,43,1) 100%);',
				example: '如果恋人说要和异性同时单独吃饭？<br />友谊型：好呀，多吃点！<br /><span style="color: rgba(0,0,0,0.5);font-size: 17px;">内心os：吃饭啊，如果能给我带点回来就更好啦！</span>',
				html:
					'友谊型喜欢朋友般的恋爱！对于友谊型的人来说，恋爱和友情有着相似的感觉。Ta们更看重随时间慢慢积累对彼此的信任，所以经常会和关系很好的朋友成为恋人。虽然不是炽热的爱情，但是是平淡长久的稳定的恋爱。Ta们需要能够共享彼此关心的事情和一起做有趣事情的恋人。比起“刺激激动的恋爱”，友谊型的人更喜欢“舒服的恋爱”。Ta们可以接受没有身体接触的恋爱。不适合相亲。',
			},
		]
		scoreArray.sort((a, b) => {
			return b.score - a.score
		})
		console.log(scoreArray)

		$('#app').html(
			TPL({
				vipHave: utils.query('vip') == '1',
			})
		)

		if (scoreArray[0]) {
			var nameId = scoreArray[0].name
			var scoreNum = scoreArray[0].score
			$('.' + nameId).css('display', 'block')
			$('.progress_box.' + nameId).css('display', 'none')
			$('.progressNum').css('width', scoreNum + '%')
			$('.progress').css('width', scoreNum + '%')
			$('.num').html(scoreNum)
		}
	}

	const func1 = async () => {
		try {
			const { statusCode, quizId, nickName, dataList } = await $.ajax(ajaxParams)
			if (statusCode === 200) {
				func3(dataList)
			}
		} catch (error) {
			console.error(error)
			iqwerty.toast.Toast('网络出错了，请稍后再试')
		}
	}

	const func2 = async () => {
		await func1()
		const chart = new F2.Chart({
			id: 'myChart',
			pixelRatio: window.devicePixelRatio,
		})

		chart.coord('polar')
		chart.source(scoreArray, {
			score: {
				min: 0,
				max: 100,
				nice: false,
				tickCount: 6,
			},
		})
		chart.axis('score', {
			label: (text, index, total) => {
				const cfg = {
					textAlign: 'right',
				}
				cfg.text = text // cfg.text 支持文本格式化处理
				return cfg
			},
			grid: {
				lineDash: null,
			},
		})
		chart.axis('item', {
			grid: {
				lineDash: null,
			},
			label(text, index, total) {
				return {
					fill: scoreArray[index].color,
				}
			},
		})

		chart.legend('user', {
			custom: true,
			items: [
				{
					marker: {},
				},
				{
					marker: {},
				},
			],
			offsetY: -30,
			position: 'bottom',
			align: 'center',
			itemFormatter: function (val, a) {
				return ''
			},
		})

		chart.tooltip(false) // 禁止显示提示框
		chart.area().position('item*score').color('score', '#4D89F7')
		chart.line().position('item*score').color('#4D89F7')
		chart.point().position('item*score').color('score', '#4D89F7').style('item', {
			lineWidth: 1,
			fill: '#fff',
		})

		chart.render()

		scoreArray.forEach((v, i) => {
			if (i !== 0) {
				var html = `<div class="alltext">
                        <div class="alltextTop" style="color:${v.color};">${v.item}</div>
                        <div class="progress_box">
                          <div class="progress" style="background:${v.background};width:${v.score}%;position: relative;${
					v.score == 0 ? 'display:none' : ''
				}"><div class="num_r" style="position: absolute;${v.score == 0 ? 'display:none' : ''}"><span>${v.score}</span>/100</div></div>
                        </div>
                      </div>
                      <div class="title_text1">${v.html}</div>
                      <div class="alltextTop" style="color:${v.color};margin-bottom: 15PX;">举个栗子</div>
                      <span class="give_example">${v.example}<span/>`

				$('.type_list').append(html)
			}
		})
	}

	func2()
})
