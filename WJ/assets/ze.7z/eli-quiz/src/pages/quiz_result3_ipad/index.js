import TPL from './index.art'
import utils from '@/js/utils'
import {
  serverUrl
} from '@/js/settings'

import '@/scss/base.scss'
import './index.scss'
let t1, t2, name

$(function () {

  const POS = '0',
    NEG = '2',
    NOR = '1';

  function score(dataList) {
    console.log(dataList)
    let counter = [0, 0, 0] // 不安数，回避数，安全数
    dataList.forEach(({
      qid,
      a
    }) => {
      // console.log(qid)
      if (qid % 2 == 1) {
        if (a == POS)
          counter[1] += 1
        else if (a == NEG)
          counter[1] -= 1
      } else {
        if (a == POS)
          counter[0] += 1
        else if (a == NEG)
          counter[0] -= 1
      }
    })
    counter[2] = counter[0] + counter[1]
    return counter;
  }

  function analysis(counter) {
    const map1 = {
        '焦虑型': 0,
        '回避型': 1,
        '安全型': 2
      },
      map2 = {
        '弱度': 0,
        '强度': 1
      }
    let str1 = '',
      str2 = '';
    if (counter[0] > 0 && counter[1] > 0) {
      str1 += counter[1] > counter[0] ? '回避型' : '焦虑型'
      str2 += (counter[1] > 5 || counter[0] > 5) ? '强度' : '弱度'
    } else if (counter[0] > 0) {
      str1 += '焦虑型'
      str2 += counter[0] > 5 ? '强度' : '弱度'
    } else if (counter[1] > 0) {
      str1 += '回避型'
      str2 += counter[1] > 5 ? '强度' : '弱度'
    } else if (counter[0] == 0 && counter[1] == 0) {
      str1 = '回避型'
      str2 = '弱度'
    } else {
      str1 += '安全型'
      str2 += counter[2] < -11 ? '强度' : '弱度'
    }
    console.log(JSON.stringify(counter), str1 + map1[str1], str2 + map2[str2])
    return (map1[str1] + 0.1 * map2[str2]).toFixed(1)
  }

  let vipHave = utils.query('vip') == '1'
  let recordId = utils.query('id')
  let quizNo = utils.query('quizNo')
  let name = utils.query('name')? decodeURIComponent(utils.query('name')): '你'

  function getDetail() {
    return $.ajax({
        type: "post",
        url: serverUrl + `support/record/result`, //?userId=${userId}&loginId=${loginId}
        data: JSON.stringify({
          recordId: parseInt(recordId),
          quizNo
        }),
        dataType: "json",
        contentType: "application/json"
      })
  }

  getDetail()
    .then(function (resp) {
      let {
        statusCode,
        nickName,
        result
      } = resp;
      // console.log(resp)
      if (statusCode === 200) {
        let answers = JSON.parse(result.answers)
        const len = answers.length / 2;
        let selfScore = score(answers.filter((_) => (_.qid <= len)))
        t1 = analysis(selfScore)

        let nameType
        if (t1[0] == 0) {
          //$(".jiaolv").css("display", "block")
          nameType = '焦虑型'
        } else if (t1[0] == 1) {
          //$(".huibi").css("display", "block")
          nameType = '回避型'
        } else if (t1[0] == 2) {
          //$(".anquan").css("display", "block")
          nameType = '安全型'
        }
        //document.getElementById("NameId").innerHTML=document.getElementById("NameId").innerHTML.replace(/B/g, name_type)
        let nameTypeLevel
        if (t1[2] == 1) {
          nameTypeLevel = '强度'
        } else {
          nameTypeLevel = '弱度'
        }

        let loverScore = score(answers.filter((_) => (_.qid > len)))
        t2 = analysis(loverScore)
        console.log(t2)
        var loverType
        if (t2[0] == 0&&t1[0] == 0) {
          // $(".jiaolv1").css("display", "block")
          loverType = '焦虑型'
        } else if (t2[0] == 1&&t1[0] == 1) {
          // $(".huibi1").css("display", "block")
          loverType = '回避型'
        } else if (t2[0] == 2&&t1[0] == 2) {
          // $(".anquan1").css("display", "block")
          loverType = '安全型'
        } else if(t2[0] == 0&&t1[0] != 0){
          // $(".jiaolv_details").css("display", "block")
          loverType = '焦虑型'
        } else if(t2[0] == 1&&t1[0] != 1){
          // $(".huibi_details").css("display", "block")
          loverType = '回避型'
        } else if(t2[0] == 2&&t1[0] != 2){
          // $(".anquan_details").css("display", "block")
          loverType = '安全型'
        }
        // document.getElementById("NameId").innerHTML=document.getElementById("NameId").innerHTML.replace(/D/g, name_type2)
        var loverTypeLevel
        if (t2[2] == 1) {
          loverTypeLevel = '强度'
        } else {
          loverTypeLevel = '弱度'
        }
        $("#app").html(TPL({
          vipHave,
          name,
          nameType,
          nameTypeLevel,
          loverType,
          loverTypeLevel
        }))
        
        if (vipHave == 0) {
          //$("#noVip").css("display", "block")
        } else {
          //$("#haveVip").css("display", "block")
          $(".icoImg").css("display", "inline-block")
          $(".card1").css("height", "55px");
          $(".card1").css("overflow", "hidden")
          $(".card1").click(function (e) {
            $(this).css("height", "auto");
            $(this).find(".icoImg").css("display", "none")
          })
        }
        
      } else {
        throw Error(statusCode);
      }
    })
    .catch(e => {
      iqwerty.toast.Toast("网络出错了，请稍后再试");
    })
})