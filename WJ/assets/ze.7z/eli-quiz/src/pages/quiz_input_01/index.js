import utils from '@/js/utils'
import { serverUrl } from '@/js/settings'

import '@/scss/base.scss'
import './index.scss'

// import Bootstrap from 'bootstrap/dist/css/bootstrap.min.css'
// import 'bootstrap/dist/css/bootstrap.min.css'

// import 'vue'
// import Vue from 'vue'
//window.Vue = require('vue')

//var serverUrl = (process.env.MOCK=="enable")? "": "http://211.95.56.10:9780/frontend";
//console.log(process.env.NODE_ENV, process.env.MOCK=="true"? "mock=true":'', serverUrl)

 var userId='100000053',loginId='39a838cd197b4e218289235d467e5a85'
// let { userId, loginId }  = utils.getUserDetailInfo() || {
//   userId: 3111,
//   loginId: '9b8e82ef638949f8aab9ece5ad06f8b8'
// }
let t1, t2, name

$(function() {


    const POS = '0', NEG='2', NOR = '1';
    
    function score(dataList){console.log(dataList)
      let counter = [0,0,0]// 不安数，回避数，安全数
      dataList.forEach(({qid, a}) => {
        // console.log(qid)
        if(qid%2==1){
          if(a==POS)
            counter[1] += 1
          else if(a==NEG)
            counter[1] -= 1
        }
        else{
          if(a==POS)
            counter[0] += 1
          else if(a==NEG)
            counter[0] -= 1
        }
      })
      counter[2] = counter[0]+counter[1]
      return counter;
    }

    function analysis(counter){
      const map1 = {'焦虑型':0,'回避型':1,'安全型':2}, map2 = {'弱度':0,'强度':1}
      let str1 = '', str2 = '';
      if(counter[0]>0 && counter[1]>0){
        str1 += counter[1]>counter[0] ? '回避型':'焦虑型'
        str2 += (counter[1]>5 || counter[0]>5)? '强度': '弱度'
      }
      else if(counter[0]>0){
        str1 += '焦虑型'
        str2 += counter[0]>5? '强度': '弱度'
      }
      else if(counter[1]>0){
        str1 += '回避型'
        str2 += counter[1]>5? '强度': '弱度'
      }
      else if(counter[0]==0 && counter[1]==0){
        str1 = '回避型'
        str2 = '弱度'
      }
      else {
        str1 += '安全型'
        str2 += counter[2]<-11? '强度': '弱度'
      }
      console.log(JSON.stringify(counter), str1+map1[str1], str2+map2[str2])
      return (map1[str1] + 0.1 * map2[str2]).toFixed(1)
    }

    function getDetail() {
      let quizId = utils.query('id')
      return $.ajax({
        type: "post",
        url: serverUrl+"quiz/question/list",
        data: JSON.stringify({quizId: parseInt(quizId), userId, loginId}),
        dataType: "json",
        contentType: "application/json"
      })
    }

    function quizSubmit(answerList) {
      let quizId = utils.query('id')
      return $.ajax({
        type: "post",
        url: serverUrl+"quiz/question/save",
        data: JSON.stringify({quizId: parseInt(quizId), answerList, userId, loginId}),
        dataType: "json",
        contentType: "application/json"
      })
    }

    let type = utils.query('type') || '1'
    if(type=='3') {
      $("body, .card, .progress-bar, .circle").addClass("t3")
    }

    getDetail()
      .then(function(resp){
        let { statusCode, dataList } = resp;
        // console.log(resp)
        if(statusCode === 200){
          let doneList = []
          let options = null
          if(type=='2'){
            $(".question").html(
              dataList.map(({ questionId, content, description }) => {
                content = JSON.parse(content)
                console.log(content)
                //description = description? description.split(/[\r\n]+/g).map(str => `<p class="description">${str}`).join(''): ''
                return (
                  `<li id="${questionId}">
                    <p class="content">${content}
                  </li>`
                  )
              }).join('')
            )
          }
          else if(type=='3'){
            $(".question").html(
              dataList.map(({ questionId, content, options }) => {
                options = JSON.parse(options)
                console.log(content, options)
                return (
                  `<li id="${questionId}">
                    <p class="content">${content}
                  </li>`
                  )
              }).join('')
            )
            options = dataList.map(({ options }) => JSON.parse(options))
          }
          else{
            $(".question").html(
              dataList.map(({ questionId, content, description }) => {
                description = description? description.split(/[\r\n]+/g).map(str => `<p class="description">${str}`).join(''): ''
                return (
                  `<li id="${questionId}">
                    <p class="content">${content}
                    ${description}
                  </li>`
                  )
              }).join('')
            )
          }

          let index=0, len = dataList.length;
          function record(index, value) {
            $(`.options`).addClass('done')
            $(".opt").removeClass('chosen')
            $(`.opt[data-a=${value}]`).addClass('chosen')
            let find = -1;
            doneList.forEach((item) => {
              if(item.qid == dataList[index-1].questionId){
                find = index - 1
                doneList[find].a = value
              }
            })
            if(find == -1){
              doneList.push({qid: dataList[index-1].questionId, a: value})
            }
            console.log(doneList)
            if(doneList.length == len){
              quizSubmit(doneList.map(({ qid, a })=>({ qid, a:a+"" })))
            }
          }

          function next() {
            if(index+1 > len) 
              return;
            $(".question li").removeClass('active').eq(index++).addClass('active')
            $(".stick").css({ width: (index)/len*100+'%' })
            $(".progress-txt").html(`<span class="curr">${index}</span>/<span class="total">${len}</span>`)

            if(type==3){
              let options_html = options[index-1].map(({ cnt, id }) => `<div class="opt" data-a="${id}">${cnt}</div>`).join('')
              $(".options").removeClass('done').addClass('t3').html(options_html)
            }
            else {
              let default_options = `<div class="opt" data-a="0">是的</div><div class="opt" data-a="1">一般</div><div class="opt" data-a="2">不是</div>`
              $(".options").removeClass('done').addClass('default').html(default_options)
            }
            $(".opt").removeClass('.chosen')
              .unbind()
              .click(function(){
                record(index, $(this).data('a'))
                setTimeout(next, 200)
                //next()
              })
            let answer = doneList.filter(item => item.qid == dataList[index-1].questionId)
            if(answer.length>0){
              $(`.options`).addClass('done')
              $(`.opt[data-a=${answer[0].a}]`).addClass('chosen').addClass()
            }
          }

          function prev() {
            if(index-1 <= 0) 
              return;
            $(".question li").removeClass('active').eq(--index-1).addClass('active')
            $(".stick").css({ width: (index)/len*100+'%' })
            $(".progress-txt").html(`<span class="curr">${index}</span>/<span class="total">${len}</span>`)

            if(type==3){
              let options_html = options[index-1].map(({ cnt, id }) => `<div class="opt" data-a="${id}">${cnt}</div>`).join('')
              $(".options").removeClass('done').addClass('t3').html(options_html)
            }
            else {
              let default_options = `<div class="opt" data-a="0">是的</div><div class="opt" data-a="1">一般</div><div class="opt" data-a="2">不是</div>`
              $(".options").removeClass('done').addClass('default').html(default_options)
            }
            $(".opt").removeClass('.chosen')
              .unbind()
              .click(function(){
                record(index, $(this).data('a'))
                setTimeout(next, 200)
                //next()
              })
            let answer = doneList.filter(item => item.qid == dataList[index-1].questionId)
            if(answer.length>0){
              $(`.options`).addClass('done')
              $(`.opt[data-a=${answer[0].a}]`).addClass('chosen')

            }
          }

          $(".prev")/*.html(`<img><span>上一题</span>`)*/.click(prev)
          next()
        }
        else {
          throw error;
        }
      })
      .catch(e => {
        iqwerty.toast.Toast("网络出错了，请稍后再试");
      })    


      /*

    let resp = {
      statusCode:200,
      msg:'ok',
      quizId:1,
      nickName:'John',
      dataList:[
        {qid:1, a:POS},
        {qid:2, a:POS},
        {qid:3, a:NOR},
        {qid:4, a:NEG},
      ]
    }
    name  = resp.nickName;
    const len = resp.dataList.length/2;
    let selfScore = score(resp.dataList.filter((_)=>(_.qid <= len)))
    t1 = analysis(selfScore)
    console.log(t1)
    let loverScore = score(resp.dataList.filter((_)=>(_.qid > len)))
    t2 = analysis(loverScore)
    console.log(t2)
    */

    $(".next").click(function(){
      if(name && t1 && t2)
        location.href = location.href.replace(/quiz_result\.html.*$/,`quiz_result1.html?name=${encodeURIComponent(name)}&type=${t1}&lover_type=${t2}`)
    })
  //$('strong').html(fmoney(123232439.3223,2))
  //new Promise(function(resolve,reject){setTimeout(()=>{let a=10;resolve(a)},2000)}).then((x)=>{console.log('Promise'+x)})
})