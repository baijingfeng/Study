const Mock = require('mockjs');//mockjs 导入依赖模块
const Random = Mock.Random;
//const util = require('./util');//自定义工具模块
//返回一个函数
module.exports = function(app){
  //监听http请求
  app.post('/mock/web/mini/game/draw', function (req, res) {
    //每次响应请求时读取mock data的json文件
    //util.getJsonFile方法定义了如何读取json文件并解析成数据对象
    //util.getJsonFile('./userInfo.json');
    let json = {
      "statusCode": 200,
      "msg": "success",
      "user_id": Random.id(),
      "reward|20-200": 20
    }
    //将json传入 Mock.mock 方法中，生成的数据返回给浏览器
    res.json(Mock.mock(json));
  });

  app.post('/mock/web/mini/game/page/info', function (req, res) {
    let json = {
      "statusCode": 200,
      "msg": "success",
      "user_id": 1,
      "time": 5,
      "taskDetailDtos": [{
          "awardTarget": 1,
          "completeStatus": true,
          "maxAwardAmount": 100,
          "minAwardAmount": 10,
          "mainHeading": "mainHeading",
          "subHeading": "subHeading",
          "taskId": 1
      }, {
          "awardTarget": 3,
          "completeStatus": false,
          "maxAwardAmount": 300,
          "minAwardAmount": 30,
          "mainHeading": "mainHeading",
          "subHeading": "subHeading",
          "taskId": 2
      }, {
          "awardTarget": 15,
          "completeStatus": false,
          "maxAwardAmount": 1500,
          "minAwardAmount": 150,
          "mainHeading": "mainHeading",
          "subHeading": "subHeading",
          "taskId": 3
      }, {
          "awardTarget": 35,
          "completeStatus": false,
          "maxAwardAmount": 3500,
          "minAwardAmount": 350,
          "mainHeading": "mainHeading",
          "subHeading": "subHeading",
          "taskId": 4
      }]
    }
    res.json(Mock.mock(json));
  });
}
